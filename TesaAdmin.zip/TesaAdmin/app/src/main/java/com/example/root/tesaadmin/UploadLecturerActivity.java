package com.example.root.tesaadmin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.root.tesaadmin.common.Common;
import com.example.root.tesaadmin.model.Lecturer;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.jaredrummler.materialspinner.MaterialSpinner;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import androidx.annotation.NonNull;

public class UploadLecturerActivity extends AppCompatActivity {

    private static final String TAG = "UploadLecturerActivity";
    private static final int PICK_IMAGE_REQUEST = 21;
    ImageView lecturerImage;

    Button selectImageBtn, uploadBtn;

    EditText name, email, officeAddress, phoneNumber, degree, level;

    MaterialSpinner spinner;

    Uri saveUri = null;

    ProgressDialog progressDialog;

    FirebaseDatabase database;
    DatabaseReference lecturers;
    FirebaseStorage storage;
    StorageReference storageReference;

    ProgressDialog mDialog;

    String[] categoriesArray = {Common.AGE, Common.CHE,
            Common.CVE, Common.CSC,
            Common.FST, Common.EEE, Common.MEE,
            Common.MSC};

    String formattedDate = "";
    String departmentS;

    String mobileN = "", emailS = "", officeS = "", nameS = "", degreeS = "", levelS = "", categoryS;

    Uri filePath;
    UploadTask uploadTask;
    Uri downloadUri;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_lecturer);

        initViews();

        initFirebase();
        init();

    }

    private void initFirebase() {
        //init Firebase
        database = FirebaseDatabase.getInstance();
        lecturers = database.getReference("Lecturers");
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
    }

    private void initViews() {

        lecturerImage = findViewById(R.id.lecturer_image);

        selectImageBtn = findViewById(R.id.add_image);

        uploadBtn = findViewById(R.id.submit);

        name = findViewById(R.id.name);

        email = findViewById(R.id.email);

        officeAddress = findViewById(R.id.office_address);

        phoneNumber = findViewById(R.id.phone_number);

        degree = findViewById(R.id.degree);

        level = findViewById(R.id.level);

    }


    private void init() {


        uploadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()){
                    emailS = email.getText().toString();

                    officeS = officeAddress.getText().toString();
                    mobileN = phoneNumber.getText().toString();
                    categoryS = categoriesArray[spinner.getSelectedIndex()];
                    levelS = level.getText().toString();
                    nameS = name.getText().toString();
                    degreeS = degree.getText().toString();

                    Log.d(TAG, "onClick: submit button clicked");
                    uploadImage();

                }

            }
        });


        selectImageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                chooseImage();

            }
        });
    }

    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    private void uploadImage() {
        if (filePath != null) {

            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading...");
            progressDialog.setMessage("please wait");
            progressDialog.show();

            String imageName = UUID.randomUUID().toString(), postNumber = UUID.randomUUID().toString();
            String currentUser = Objects.requireNonNull(FirebaseAuth.getInstance().getCurrentUser()).getUid();
            final StorageReference ref = storageReference.child("images/" + "/lecturers/" + imageName+postNumber);

            departmentS =  categoriesArray[spinner.getSelectedIndex()];

            uploadTask = ref.putFile(filePath);


            Task<Uri> uriTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if (!task.isSuccessful()) {
                        throw Objects.requireNonNull(task.getException());
                    }
                    return ref.getDownloadUrl();
                }
            })
                    .addOnCompleteListener(new OnCompleteListener<Uri>() {
                        @Override
                        public void onComplete(@NonNull Task<Uri> task) {
                            if (task.isSuccessful()) {
                                downloadUri = task.getResult();

                                // database.getReference(Common.NODE_POST_ITEM).child(user.getUid()).child("imageUrl")
//                                        .push().setValue(downloadUri);

                                Date c = Calendar.getInstance().getTime();


                                DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

                                formattedDate = df.format(c);
                                lecturers = database.getReference(Common.NODE_LECTURERS)
                                        .child(categoriesArray[spinner.getSelectedIndex()]);

                                String key = lecturers.push().getKey();



                                Lecturer post = new Lecturer(nameS, emailS, officeS, mobileN, degreeS, levelS,
                                         departmentS, downloadUri.toString());

                                Map<String, Object> postValues = post.toMap();



                                Map<String, Object> childValues = new HashMap<>();


                                assert key != null;
                                childValues.put(key, postValues);


                                lecturers.updateChildren(childValues);


                                resetFields();
                                startActivity(new Intent(UploadLecturerActivity.this, HomeActivity.class));
                                finish();

                                progressDialog.dismiss();
                            }
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {

                        }
                    });

        }
    }

    private void resetFields() {

        name.setText("");
        email.setText("");
        phoneNumber.setText("");
        officeAddress.setText("");
        degree.setText("");
        level.setText("");
    }

    public boolean validate() {
        boolean valid = true;

        mobileN = phoneNumber.getText().toString();
        emailS = name.getText().toString();
        officeS = officeAddress.getText().toString();
        nameS = email.getText().toString();
        degreeS = degree.getText().toString();
        levelS = level.getText().toString();


        if (mobileN.isEmpty() || mobileN.length() != 11) {
            phoneNumber.setError("Please enter valid number");
            valid = false;
        } else {
            phoneNumber.setError(null);
        }


        if (emailS.isEmpty() || emailS.length() < 5) {

            email.setError("Please enter THe lecturer email");
            valid = false;
        } else {
            email.setError(null);

        }

        if (officeS.isEmpty() || officeS.length() < 10) {

            officeAddress.setError("Please enter the office address");
            valid = false;
        } else {
            officeAddress.setError(null);

        }

        if (nameS.isEmpty()) {

            name.setError("Please enter the name");
            valid = false;
        } else {
            name.setError(null);

        }

        if (degreeS.isEmpty()) {

            degree.setError("Please enter the lecturer's degree");
            valid = false;
        } else {
            degree.setError(null);

        }
        if (levelS.isEmpty()){
            level.setError("Please enter level");
            valid = false;
        }else {
            level.setError(null);
        }


        return valid;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            // When an Image is picked
            if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                    && null != data) {
                // Get the Image from data

                if (data.getData() != null) {

                    filePath = data.getData();

                    saveUri = filePath;

                    CropImage.activity(filePath)
                            .setGuidelines(CropImageView.Guidelines.ON)
                            .setAspectRatio(1,1)
                            .start(this);


                } else {

                }
            } else {
                Toast.makeText(this, "You haven't picked Image",
                        Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG)
                    .show();
        }


        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE){
            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            if (resultCode == RESULT_OK){
                assert result != null;
                saveUri = result.getUri();
                addImage.setImageURI(saveUri);
            }else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE){
                assert result != null;
                Log.e(TAG, "onActivityResult: "+ result.getError() );
            }
        }
    }
}
